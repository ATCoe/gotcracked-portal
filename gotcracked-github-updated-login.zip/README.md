# GotCracked websites

This repository contains both GotCracked deployment targets:

- Repository root: customer website for `https://gotcracked.co`
- `portal/`: authenticated staff portal for `https://portal.gotcracked.co`

## Deploy from GitHub with Cloudflare Pages

1. Upload this folder's contents to the GitHub repository root and commit to `main`.
2. Create a Cloudflare Pages project for the customer site. Connect this repository, use no build command, publish the repository root, and attach `gotcracked.co`.
3. Create a second Cloudflare Pages project from the same repository. Set `portal` as its root/output directory and attach `portal.gotcracked.co`.
4. In Supabase **Authentication → URL Configuration**, set the Site URL to `https://portal.gotcracked.co` and add that exact address to Redirect URLs.
5. Confirm that the Supabase reset-password email template uses `{{ .ConfirmationURL }}`.

## Included

- Responsive customer-facing site using the official GotCracked brand assets
- Services, process, warranty, FAQ, repair request, and tracking interfaces
- Supabase-authenticated staff portal
- Updated sign-in, sign-out, session restoration, forgot-password, recovery callback, and new-password flows
- Portal database schema, migration, and production notes
- Explicit navigation between the customer domain and portal subdomain

## Production integration still required

The portal is connected to Supabase for staff authentication and authorized repair records. The customer request and tracking interfaces intentionally remain local until a protected API is deployed.

Because browser storage cannot be shared between `gotcracked.co` and `portal.gotcracked.co`, connect customer intake through a Supabase Edge Function or another server endpoint. Protect tracking with an expiring customer link or server-side identity check; do not add anonymous read access to customer or repair tables.

Also confirm the final phone number, address, hours, support email, privacy policy, terms, and warranty language before launch.
